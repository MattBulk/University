void graphBuilder();
void createPaths();
