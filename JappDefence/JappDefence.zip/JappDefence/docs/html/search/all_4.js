var searchData=
[
  ['endscreentext',['endScreenText',['../Gui_8cpp.html#a85def87de1dcac6ee564d19252f906fa',1,'Gui.cpp']]]
];
