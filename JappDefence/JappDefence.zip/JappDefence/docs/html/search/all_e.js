var searchData=
[
  ['resetlevel',['resetLevel',['../GameBuild_8cpp.html#a8426e14ff8c1df4474b35f0ded4e8c99',1,'resetLevel():&#160;GameBuild.cpp'],['../GameBuild_8h.html#a8426e14ff8c1df4474b35f0ded4e8c99',1,'resetLevel():&#160;GameBuild.cpp']]]
];
