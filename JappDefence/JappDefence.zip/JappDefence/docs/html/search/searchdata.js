var indexSectionsWithContent =
{
  0: "abcdeghiklmnoprstuvw",
  1: "abg",
  2: "acgmp",
  3: "acdgilmoprstu",
  4: "abcdeghklmnopstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili"
};

