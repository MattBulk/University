var searchData=
[
  ['killed',['killed',['../structalien.html#aec4346a4a64540077f3b0795570b128e',1,'alien']]]
];
