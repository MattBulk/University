var searchData=
[
  ['objectpositiontovertex',['objectPositionToVertex',['../GameLoop_8cpp.html#a1f7bac01d22d28619648f19926486b3f',1,'objectPositionToVertex(sf::Vector2f objPos):&#160;GameLoop.cpp'],['../GameLoop_8h.html#a1f7bac01d22d28619648f19926486b3f',1,'objectPositionToVertex(sf::Vector2f objPos):&#160;GameLoop.cpp']]]
];
