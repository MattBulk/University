var searchData=
[
  ['h_5fdim',['H_DIM',['../classGConst.html#a63ca668ad7ec012fcac292088b265222',1,'GConst']]],
  ['h_5foffset',['H_OFFSET',['../classGConst.html#ac47bc477cf1ec6ccb5af58a5711be51f',1,'GConst']]]
];
