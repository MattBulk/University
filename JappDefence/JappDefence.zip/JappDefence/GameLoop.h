
void moveHero(std::string direction);
void getInput(std::string input);
void updateGame();
int objectPositionToVertex(sf::Vector2f objPos);
void setGameLoopVars();
