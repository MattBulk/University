#include "Constants.h"

const int GConst::STAGE_WIDTH;
const int GConst::STAGE_HEIGHT;

/** GUI CONSTANTS */
const int GConst::GUI_DIM;

/** GAME BUILD */
const int GConst::H_DIM;
const int GConst::W_DIM;
const int GConst::H_OFFSET;
const int GConst::TILE_SIZE;
const int GConst::B_DIM;
